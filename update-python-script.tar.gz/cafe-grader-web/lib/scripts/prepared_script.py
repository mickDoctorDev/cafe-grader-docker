import re
import sys

def main():
    # Read all input from standard input
    input_text = sys.stdin.read().strip()
    
    if not input_text:
        return

    email = input_text
    username_part = email.split('@')[0]
    cleaned_username = re.sub(r'[^a-zA-Z0-9]', '', username_part)
    
    print(cleaned_username)

if __name__ == "__main__":
    main()
